# How To Compile

1. 使用Qt Creator開啟`Pokemon.pro`
2. 點configure
3. 選Release版（不要選Debug）
4. 點左下角的綠色箭號編譯並執行
5. 將test case資料夾中的檔案負製到Qt Creator放Makefile的資料夾
6. 點畫面中的Start Game開始遊戲